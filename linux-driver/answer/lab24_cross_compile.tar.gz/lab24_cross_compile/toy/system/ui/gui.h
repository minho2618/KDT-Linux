#ifndef _GUI_H
#define _GUI_H

int create_gui();

#endif /* _GUI_H */
